# Membuat APK Exam Browser V4 tanpa Android Studio

Paket ini merupakan **source code**, bukan APK yang sudah dikompilasi. File `.github/workflows/build-apk.yml` menjalankan build di GitHub Actions.

## Langkah GitHub Actions
1. Buat repository **privat** baru di GitHub (jangan unggah konfigurasi database dengan password asli).
2. Upload **isi folder `ExamBrowserAndroid_V4_Server`** ke bagian utama repository, termasuk folder `.github`, `android` dan `server`. Jangan unggah hanya ZIP.
3. Buka tab **Actions** → **Build Exam Browser APK** → **Run workflow**.
4. Setelah proses build **berhasil**, buka run tersebut, lalu unduh artifact `ExamBrowser-V4-Android-APK`.
5. Ekstrak artifact. File `app-debug.apk` dapat dipasang pada HP Android 8 ke atas (bila pengaturan instalasi APK diizinkan).

## Alternatif Android Studio
1. Buka folder `android` lewat Android Studio.
2. Tunggu sinkronisasi Gradle (versi 8.9, Android Gradle Plugin 8.7.3) dan pemasangan Android SDK Platform 35.
3. Klik **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Cari APK di `android/app/build/outputs/apk/debug/app-debug.apk`.

## Sebelum penggunaan nyata
- Pasang dan konfigurasi server PHP + MySQL sesuai `README.md`.
- Isi endpoint HTTPS API (`https://domain-sekolah/.../api.php`) dan PIN pengawas di aplikasi.
- Uji login, jadwal ujian, token, laporan kejadian, serta kompatibilitas WebView pada HP siswa.
- APK debug cocok untuk uji coba, bukan distribusi produksi. Untuk distribusi, tanda tangani release APK dengan keystore sekolah.
- Pada HP pribadi, Screen Pinning tetap dapat dilepas siswa menggunakan kontrol Android; aplikasi tidak dapat menjamin pemblokiran total aplikasi lain.
