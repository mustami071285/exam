# Exam Browser V4 BYOD + Server Ujian Sekolah

Paket sumber kode untuk **MIN 1 Bangkalan** (nama tampilan dapat diubah). Belum dikompilasi sebagai APK dan **belum melalui uji perangkat maupun uji keamanan produksi**.

## Isi paket

- `android/` proyek Android Studio, Java, API minimum 26 (Android 8), WebView, Android Screen Pinning.
- `server/` backend PHP 8.1+ / PDO MySQL 5.7+/MariaDB, halaman pengawas `admin.php`, API `api.php`, SQL `schema.sql`.

## Alur operasional

1. Administrator membuat peserta (NIS, nama, kata sandi) di `admin.php`.
2. Administrator membuat ujian: judul, URL CBT (HTTPS), token rahasia, awal/akhir jadwal.
3. Siswa membuka APK, mengisi NIS/kata sandi/token ujian.
4. Server memeriksa peserta aktif, kata sandi, token, dan jadwal di server (zona Asia/Jakarta). Bila sah, server menerbitkan bearer token sesi acak dan URL CBT.
5. Android memuat URL CBT dalam WebView, meminta Screen Pinning dan mencatat kejadian yang dapat dideteksi: fokus hilang/kembali, aplikasi jeda/kembali, navigasi terlarang, permintaan download, TLS error, dll.
6. Android mengirim catatan dalam batch ke server dan heartbeat tiap 30 detik **selagi aplikasi berjalan**. Catatan yang belum terkirim disimpan lokal sementara dan dicoba ulang sesuai masa berlaku sesi.
7. Pengawas membuka dashboard, memilih jumlah kejadian pada sebuah sesi untuk membaca laporan.

**Penting**: Ini lapisan verifikasi peserta sebelum masuk halaman CBT, **bukan** sistem pembuatan/penilaian soal. Jika website CBT sendiri mempunyai login, siswa mungkin tetap perlu login di situ. Token ini diverifikasi oleh server Exam Browser, bukan oleh website CBT eksternal.

## Instalasi server (hosting PHP + MySQL)

1. Buat database dan pengguna database terbatas, misalnya `exam_browser`.
2. Import `server/schema.sql` dengan phpMyAdmin atau `mysql -u ... -p exam_browser < schema.sql`.
3. Salin `server/config.example.php` menjadi `server/config.php`, isi DSN, nama pengguna dan kata sandi DB.
4. Upload seluruh isi `server/` ke subfolder HTTPS hosting, misalnya `https://cbt.sekolah.sch.id/exambrowser/`.
5. Buat admin **melalui shell hosting**: `php setup_admin.php admin 'PasswordAdminPanjangUnik'`. Jika hosting tanpa SSH, buat hash dengan `password_hash()` secara lokal dan masukkan admin lewat phpMyAdmin secara aman. **Jangan** menaruh script setup berbasis web ke folder publik.
6. Setelah admin dibuat, hapus `setup_admin.php` dari lokasi publik dan pastikan `config.php` serta `schema.sql` tidak dapat diunduh. Sebaiknya simpan rahasia konfigurasi di luar document root jika hosting mengizinkan.
7. Akses `https://cbt.sekolah.sch.id/exambrowser/admin.php`, login, tambah siswa dan ujian.
8. Gunakan alamat API **lengkap** `https://cbt.sekolah.sch.id/exambrowser/api.php` dalam aplikasi Android.

Server **wajib HTTPS valid**, konfigurasi PHP `pdo_mysql`, `session`, `openssl`; database MySQL disetel ke `+07:00` agar pemeriksaan jadwal sinkron dengan dashboard (untuk WIB). Admin `datetime-local` diisi waktu WIB.

## Instalasi Android

1. Buka folder `android/` sebagai *project* di Android Studio.
2. Tunggu sinkronisasi Gradle (membutuhkan Android SDK/API 35 & internet untuk plugin Gradle).
3. Menu `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`.
4. Ambil APK dari `android/app/build/outputs/apk/debug/` dan instal di perangkat uji (izinkan sumber instalasi tepercaya sesuai aturan perangkat).
5. Buka aplikasi → Pengaturan pengawas → masukkan URL lengkap `api.php` dan PIN pengawas 6–12 digit.
6. Aktifkan **Sematkan Aplikasi / Screen Pinning** di Android, dengan persetujuan pemilik HP.
7. Buat ujian aktif di dashboard lalu login sebagai siswa.
8. Saat selesai, pengawas mengetuk judul layar ujian 7 kali lalu memasukkan PIN pengawas. Siswa tetap dapat menghentikan Screen Pinning dari Android.

## Keamanan dan batasan

- BYOD tanpa Device Owner **tidak bisa menjamin** siswa tidak akan membuka aplikasi lain. `startLockTask()` memicu penyematan layar dengan konfirmasi Android dan siswa dapat melepas sematan. Pengawas dapat melihat indikasi kehilangan fokus, tetapi aplikasi **tidak dapat melihat aplikasi apa yang dibuka**.
- Kehilangan fokus juga bisa disebabkan telepon, dialog sistem, atau gangguan; catatan **bukan bukti kecurangan**.
- Aplikasi menggunakan `FLAG_SECURE` yang membatasi tangkapan layar Android pada perangkat yang mendukung; tidak mencegah foto memakai HP lain.
- Aplikasi tidak menggunakan izin Accessibility, tidak membaca pesan, galeri, mikrofon, maupun aplikasi lain.
- Token sesi disimpan sebagai hash SHA-256 di database; token tidak dipakai untuk mengakses CBT eksternal. Password dan token ujian di-hash dengan algoritme `password_hash` PHP.
- Berkas antrian laporan tersimpan di `SharedPreferences` privat aplikasi, namun bukan penyimpanan terenkripsi. Jika HP di-root atau disusupi, integritas catatan tidak dijamin.
- Pengiriman terlambat hanya dapat diterima selama sesi valid; sesudah jam ujian selesai laporan mungkin tidak dapat terkirim. Koneksi/server mati dan mematikan aplikasi dapat mengakibatkan catatan tidak lengkap.
- WebView memblokir popup/unduhan/unggahan dan perpindahan domain utama. Website CBT yang memerlukan SSO domain lain, kamera, lampiran, popup, atau download perlu penyesuaian khusus.
- Rate-limit awal 12 kegagalan login per IP dalam 15 menit. Tambahkan WAF, proteksi admin, rate limiting per akun, log audit admin, backup DB, kebijakan retensi data, dan pengujian sebelum produksi. Jadwalkan pembersihan `login_attempts` lama.
- Dashboard menampilkan 100 siswa/ujian/sesi terakhir dan 300 kejadian terakhir per sesi; belum ada paginasi/CSV.
- Jika hosting memakai reverse proxy terminasi HTTPS, periksa `https_required` dan pengaturan origin, jangan mematikan validasi HTTPS tanpa kontrol pengganti.

## Uji penerimaan sebelum pelaksanaan ujian

1. Token salah, kata sandi salah, sebelum jadwal, setelah jadwal → ditolak.
2. Token benar dan jadwal aktif → URL CBT terbuka.
3. Coba navigasi ke domain lain dan permintaan download → diblokir/dicatat.
4. Nonaktifkan internet sementara, lalu nyalakan → amati log server dan kondisi laporan tertunda.
5. Lepas Screen Pinning dengan kontrol Android → lihat batasannya; jangan menganggap fitur sebagai anti-cheat mutlak.
6. Tutup ujian dengan PIN pengawas → sesi selesai di server bila koneksi tersedia.
7. Uji pada beberapa merek HP Android dan uji kompatibilitas situs CBT sekolah.

## Persyaratan build

Proyek hanya menyertakan kode sumber. Belum tersedia Gradle wrapper maupun APK terkompilasi. Untuk build gunakan Android Studio dengan Gradle/Android Gradle Plugin yang kompatibel dengan konfigurasi root `android/build.gradle`.
