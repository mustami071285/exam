# Exam Browser V4 Android

Baca `../README.md` untuk pemasangan server, konfigurasi APK, pengamanan BYOD dan uji. Proyek ini adalah kode sumber, bukan APK siap instal.
