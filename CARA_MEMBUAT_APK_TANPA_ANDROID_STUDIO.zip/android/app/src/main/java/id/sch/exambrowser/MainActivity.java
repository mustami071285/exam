package id.sch.exambrowser;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.SafeBrowsingResponse;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/** Exam Browser V4 BYOD: server validates credentials, exam token and scheduled time.
 *  Screen Pinning is removable by the user on personally managed Android devices.
 */
public final class MainActivity extends Activity {
    private static final String PREF="exam_v4", BASE_PREF="exam_config_v2";
    private SharedPreferences prefs, legacy;
    private LinearLayout root;
    private WebView web;
    private TextView status;
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean active=false, busy=false, flushing=false, lockingRequested=false;
    private int secretTaps=0, failedPins=0;
    private long lastTap=0, lockUntil=0;
    private String accessToken="", examUrl="", studentName="", examTitle="";
    private JSONArray pending=new JSONArray();
    private final Runnable heartbeat=new Runnable(){ @Override public void run(){
        if(!active)return;
        sendHeartbeat();flush();handler.postDelayed(this,30000);
    }};

    @Override public void onCreate(Bundle b){super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        prefs=getSharedPreferences(PREF,MODE_PRIVATE);
        legacy=getSharedPreferences(BASE_PREF,MODE_PRIVATE);
        restoreQueue();retryOutbox();home();
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView txt(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(20,50,80));t.setPadding(0,dp(9),0,dp(9));return t;}
    private Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    private EditText edit(String hint,int type){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setInputType(type);return e;}
    private void layout(boolean scroll){root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(16),dp(14),dp(16),dp(14));root.setBackgroundColor(0xfff4f8fd);
        if(scroll){ScrollView sv=new ScrollView(this);sv.addView(root);setContentView(sv);}else setContentView(root);}
    private void msg(String title,String message){if(!isFinishing())new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("Tutup",null).show();}
    private void home(){
        active=false;handler.removeCallbacks(heartbeat);getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(0);layout(true);
        root.addView(txt("EXAM BROWSER V4 — MIN 1 BANGKALAN",23));
        root.addView(txt("HP pribadi siswa • Server ujian sekolah • Android 8+",14));
        root.addView(txt("Screen Pinning membantu membatasi perpindahan aplikasi, tetapi siswa tetap dapat melepas sematan dari sistem Android.",14));
        Button set=btn("Pengaturan alamat server (PIN pengawas)");
        set.setOnClickListener(v->{if(pinIsSet())askPin(this::settings);else settings();});root.addView(set);
        Button guide=btn("Panduan aktifkan Screen Pinning");guide.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Petunjuk HP")
            .setMessage("Buka Setelan → Keamanan → Sematkan aplikasi / Screen Pinning. Aktifkan opsi meminta PIN/pola saat melepas bila tersedia. Nama pengaturan berbeda pada setiap HP. Screen Pinning tidak setara dengan penguncian Device Owner.")
            .setNegativeButton("Tutup",null).setPositiveButton("Buka Setelan",(d,w)->{try{startActivity(new Intent(Settings.ACTION_SECURITY_SETTINGS));}catch(Exception ignored){}}).show());root.addView(guide);
        root.addView(txt("LOGIN PESERTA UJIAN",19));
        EditText nis=edit("NIS / nomor peserta",InputType.TYPE_CLASS_TEXT);
        EditText password=edit("Kata sandi siswa",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText exam=edit("Token ujian dari pengawas",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        root.addView(nis);root.addView(password);root.addView(exam);
        Button login=btn("Verifikasi dan Mulai Ujian");root.addView(login);
        login.setOnClickListener(v->{String base=prefs.getString("server","");
            if(!validServer(base)||!pinIsSet()){msg("Belum diatur","Pengawas harus menyimpan URL API server dan PIN terlebih dahulu.");return;}
            String n=nis.getText().toString().trim(),p=password.getText().toString(),t=exam.getText().toString().trim();
            if(n.isEmpty()||p.isEmpty()||t.isEmpty()){msg("Data belum lengkap","Masukkan NIS, kata sandi, dan token ujian.");return;}
            if(busy)return;busy=true;login.setEnabled(false);login.setText("Memverifikasi di server...");
            try{JSONObject req=new JSONObject();req.put("nis",n);req.put("password",p);req.put("exam_token",t);req.put("client_nonce",UUID.randomUUID().toString());
                io.execute(()->{try{JSONObject r=post(base+"?action=login",req,null);
                    runOnUiThread(()->{busy=false;login.setEnabled(true);login.setText("Verifikasi dan Mulai Ujian");
                        if(r.optBoolean("ok")){start(r);}else msg("Login ditolak",r.optString("message","Ujian belum bisa diakses"));});
                }catch(Exception ex){runOnUiThread(()->{busy=false;login.setEnabled(true);login.setText("Verifikasi dan Mulai Ujian");msg("Koneksi gagal","Periksa internet dan alamat server. " + ex.getMessage());});}});
            }catch(Exception e){busy=false;login.setEnabled(true);}
        });
        root.addView(txt("Data laporan: perpindahan/fokus yang terdeteksi dikirim ke server sekolah. Tidak membaca isi aplikasi lain, pesan, atau aktivitas pribadi.",13));
        if(prefs.getString("queue","[]").length()>2)root.addView(txt("Catatan belum terkirim dari sesi terakhir akan dicoba saat sesi aktif berikutnya (bila masih ada token sesi yang sah).",12));
    }
    private boolean pinIsSet(){return prefs.contains("pin_hash")||legacy.contains("pin_hash");}
    private void settings(){layout(true);root.addView(txt("PENGATURAN PENGAWAS",23));
        root.addView(txt("Alamat endpoint API harus HTTPS, contoh https://cbt.sekolah.sch.id/exambrowser/api.php",14));
        EditText endpoint=edit("https://.../api.php",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_URI);endpoint.setText(prefs.getString("server",""));root.addView(endpoint);
        EditText pin=edit("PIN pengawas baru (6–12 angka)",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);root.addView(pin);
        Button save=btn("Simpan");root.addView(save);save.setOnClickListener(v->{String url=endpoint.getText().toString().trim();String candidate=pin.getText().toString();
            if(!validServer(url)){msg("URL tidak valid","Wajib HTTPS dan path berakhir dengan /api.php, tanpa query atau fragment.");return;}
            if((!pinIsSet()&&candidate.isEmpty())||(!candidate.isEmpty()&&!candidate.matches("[0-9]{6,12}"))){msg("PIN tidak valid","PIN harus 6–12 angka.");return;}
            SharedPreferences.Editor e=prefs.edit().putString("server",url);
            if(!candidate.isEmpty()){byte[] salt=new byte[16];new SecureRandom().nextBytes(salt);e.putString("pin_salt",hex(salt)).putString("pin_hash",pbkdf2(candidate,salt));}
            e.apply();home();});Button back=btn("Kembali");back.setOnClickListener(v->home());root.addView(back);
    }
    private boolean validServer(String url){try{Uri u=Uri.parse(url);return "https".equalsIgnoreCase(u.getScheme())&&u.getHost()!=null&&u.getHost().contains(".")
        &&u.getPort()==-1&&(u.getEncodedAuthority()==null || !u.getEncodedAuthority().contains("@"))&&u.getQuery()==null&&u.getFragment()==null&&"api.php".equals(u.getLastPathSegment())&&!url.contains("\\");}catch(Exception e){return false;}}
    private boolean allowed(Uri u){Uri base=Uri.parse(examUrl);return "https".equalsIgnoreCase(u.getScheme())&&u.getHost()!=null
        &&u.getHost().equalsIgnoreCase(base.getHost())&&u.getPort()==-1&&(u.getEncodedAuthority()==null || !u.getEncodedAuthority().contains("@"));}
    private void start(JSONObject auth){
        String url=auth.optString("exam_url","");if(!url.startsWith("https://")){msg("Server tidak valid","Alamat ujian tidak menggunakan HTTPS");return;}
        accessToken=auth.optString("session_token","");examUrl=url;studentName=auth.optString("student_name","");examTitle=auth.optString("exam_title","");
        if(accessToken.isEmpty()||!allowed(Uri.parse(url))){msg("Server tidak valid","Alamat sesi atau token tidak valid");return;}
        // Old crash-session events are preserved separately for retry, not reattributed.
        pending=new JSONArray();persistQueue();active=true;lockingRequested=false;getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        immersive();layout(false);TextView head=txt("UJIAN: "+examTitle+"  •  "+studentName,16);head.setBackgroundColor(0xffd4e7f6);root.addView(head);
        head.setOnClickListener(v->{long n=SystemClock.elapsedRealtime();if(n-lastTap>2500)secretTaps=0;lastTap=n;if(++secretTaps>=7){secretTaps=0;askPin(this::finish);}});
        status=txt("Memuat halaman ujian...",12);root.addView(status);
        web=new WebView(this);root.addView(web,new LinearLayout.LayoutParams(-1,0,1));
        android.webkit.WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowContentAccess(false);s.setAllowFileAccess(false);
        s.setAllowFileAccessFromFileURLs(false);s.setAllowUniversalAccessFromFileURLs(false);s.setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setJavaScriptCanOpenWindowsAutomatically(false);s.setSupportMultipleWindows(false);s.setSafeBrowsingEnabled(true);s.setGeolocationEnabled(false);
        web.setDownloadListener((a,b,c,d,e)->record("DOWNLOAD_BLOCKED","Permintaan mengunduh diblokir"));
        web.setWebChromeClient(new WebChromeClient(){@Override public void onPermissionRequest(PermissionRequest r){r.deny();}
            @Override public boolean onShowFileChooser(WebView w,android.webkit.ValueCallback<Uri[]> cb,FileChooserParams p){cb.onReceiveValue(null);return true;}
            @Override public boolean onCreateWindow(WebView w,boolean isDialog,boolean gesture,android.os.Message message){return false;}});
        CookieManager.getInstance().setAcceptThirdPartyCookies(web,false);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){if(!r.isForMainFrame())return false;
                if(allowed(r.getUrl()))return false;record("NAV_BLOCKED","Navigasi keluar domain ujian");return true;}
            @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap icon){if(!allowed(Uri.parse(url))){v.stopLoading();record("NAV_BLOCKED","Pengalihan diblokir");}}
            @Override public void onPageFinished(WebView v,String url){if(status!=null)status.setText("Ujian aktif • Hubungi pengawas jika terjadi kendala");}
            @Override public void onReceivedSslError(WebView v,SslErrorHandler h,SslError err){h.cancel();record("TLS_ERROR","Masalah sertifikat HTTPS");}
            @Override public void onSafeBrowsingHit(WebView v,WebResourceRequest r,int type,SafeBrowsingResponse cb){record("UNSAFE_SITE","Peringatan situs berbahaya");cb.backToSafety(true);}
            @Override public void onReceivedError(WebView v,WebResourceRequest r,android.webkit.WebResourceError err){if(r.isForMainFrame()){record("LOAD_ERROR","Gagal memuat halaman");if(status!=null)status.setText("Gagal memuat. Periksa koneksi.");}}
        });
        Button reload=btn("Muat Ulang");reload.setOnClickListener(v->{record("RELOAD","Muat ulang halaman");web.reload();});root.addView(reload);
        record("EXAM_START","Siswa memulai sesi ujian");web.loadUrl(examUrl);
        try{startLockTask();lockingRequested=true;record("PIN_REQUEST","Meminta Screen Pinning Android");}
        catch(Exception e){record("PIN_ERROR","Screen Pinning tidak tersedia");msg("Peringatan keamanan","Screen Pinning tidak aktif, hubungi pengawas.");}
        handler.postDelayed(heartbeat,30000);
    }
    private void finish(){if(!active)return;record("EXAM_END","Selesai melalui PIN pengawas");
        active=false;handler.removeCallbacks(heartbeat);
        String token=accessToken;String base=prefs.getString("server","");JSONArray copy=pending;
        saveOutbox(token,base,copy,true);
        pending=new JSONArray();persistQueue();retryOutbox();
        if(web!=null){root.removeView(web);web.stopLoading();web.loadUrl("about:blank");web.destroy();web=null;}
        try{if(lockingRequested)stopLockTask();}catch(Exception ignored){}home();
    }
    private void saveOutbox(String token,String base,JSONArray batch,boolean finish){
        try{JSONObject pack=new JSONObject();pack.put("token",token);pack.put("base",base);pack.put("events",batch);pack.put("finish",finish);
            prefs.edit().putString("outbox",pack.toString()).apply();}catch(Exception ignored){}
    }
    private void retryOutbox(){String raw=prefs.getString("outbox","");if(raw.isEmpty())return;
        io.execute(()->{try{JSONObject old=new JSONObject(raw);String token=old.getString("token");String base=old.getString("base");
            JSONObject req=new JSONObject();req.put("events",old.getJSONArray("events"));
            JSONObject sent=post(base+"?action=events",req,token);
            if(!sent.optBoolean("ok"))return;
            if(old.optBoolean("finish")){JSONObject end=post(base+"?action=finish",new JSONObject(),token);if(!end.optBoolean("ok"))return;}
            if(raw.equals(prefs.getString("outbox","")))prefs.edit().remove("outbox").apply();
        }catch(Exception ignored){ /* Retry on next app start; events may expire with server session. */ }});
    }
    private void record(String type,String detail){if(!active)return;try{JSONObject j=new JSONObject();j.put("uuid",UUID.randomUUID().toString());j.put("type",type);j.put("detail",detail);
        j.put("at",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX",Locale.US).format(new Date()));
        if(pending.length()<500)pending.put(j);persistQueue();if(pending.length()>=20)flush();}catch(Exception ignored){}
    }
    private void persistQueue(){prefs.edit().putString("queue",pending.toString()).putString("queue_token",accessToken).apply();}
    private void restoreQueue(){try{pending=new JSONArray(prefs.getString("queue","[]"));accessToken=prefs.getString("queue_token","");
        if(pending.length()>0 && !accessToken.isEmpty() && prefs.getString("outbox","").isEmpty()){
            saveOutbox(accessToken,prefs.getString("server",""),pending,false);
            pending=new JSONArray();persistQueue();
        }
    }catch(Exception e){pending=new JSONArray();}}
    private void flush(){if(!active||flushing||pending.length()==0)return;flushing=true;
        JSONArray batch=new JSONArray();int n=Math.min(50,pending.length());for(int i=0;i<n;i++)batch.put(pending.optJSONObject(i));
        String token=accessToken,base=prefs.getString("server","");
        io.execute(()->{boolean success=false;try{JSONObject req=new JSONObject();req.put("events",batch);
            JSONObject result=post(base+"?action=events",req,token);success=result.optBoolean("ok");}catch(Exception ignored){}
            final boolean sent=success;runOnUiThread(()->{if(sent&&token.equals(accessToken)){
                JSONArray remaining=new JSONArray();for(int i=n;i<pending.length();i++)remaining.put(pending.optJSONObject(i));pending=remaining;persistQueue();}
                flushing=false;
            });
        });
    }
    private void sendHeartbeat(){if(!active)return;String token=accessToken,base=prefs.getString("server","");io.execute(()->{
        try{JSONObject r=post(base+"?action=heartbeat",new JSONObject(),token);
            if(!r.optBoolean("ok"))runOnUiThread(()->{if(active)status.setText("Sesi tidak valid. Hubungi pengawas.");});
        }catch(Exception e){runOnUiThread(()->{if(active&&status!=null)status.setText("Koneksi server terputus; laporan disimpan sementara.");});}
    });}
    private JSONObject post(String endpoint,JSONObject data,String token)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(endpoint).openConnection();
        try{c.setRequestMethod("POST");c.setConnectTimeout(12000);c.setReadTimeout(12000);c.setDoOutput(true);
            c.setRequestProperty("Content-Type","application/json; charset=utf-8");c.setRequestProperty("Accept","application/json");
            if(token!=null)c.setRequestProperty("Authorization","Bearer "+token);
            byte[] bytes=data.toString().getBytes(StandardCharsets.UTF_8);
            try(OutputStream out=c.getOutputStream()){out.write(bytes);}
            int code=c.getResponseCode();InputStream stream=code<400?c.getInputStream():c.getErrorStream();
            if(stream==null)throw new Exception("HTTP "+code);
            byte[] response;try(InputStream input=stream;ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] buf=new byte[4096];int n;while((n=input.read(buf))!=-1){out.write(buf,0,n);if(out.size()>131072)throw new Exception("Respons server terlalu besar");}response=out.toByteArray();}
            JSONObject r=new JSONObject(new String(response,StandardCharsets.UTF_8));
            if(code>=400&&r.optString("message","").isEmpty())throw new Exception("HTTP "+code);
            return r;
        }finally{c.disconnect();}
    }
    private void askPin(Runnable yes){if(SystemClock.elapsedRealtime()<lockUntil){msg("Ditunda","Terlalu banyak percobaan PIN salah.");return;}
        EditText input=edit("PIN pengawas",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("PIN pengawas").setView(input).setNegativeButton("Batal",null).setPositiveButton("Verifikasi",(d,w)->{
            if(checkPin(input.getText().toString())){failedPins=0;yes.run();}else{failedPins++;if(failedPins>=5){lockUntil=SystemClock.elapsedRealtime()+60000;failedPins=0;}msg("Ditolak","PIN salah.");}
        }).show();
    }
    private boolean checkPin(String p){try{String salt=prefs.getString("pin_salt","");String hash=prefs.getString("pin_hash","");
        if(!salt.isEmpty()&&!hash.isEmpty())return MessageDigest.isEqual(pbkdf2(p,unhex(salt)).getBytes(StandardCharsets.US_ASCII),hash.getBytes(StandardCharsets.US_ASCII));
        String oldSalt=legacy.getString("pin_salt","");String oldHash=legacy.getString("pin_hash","");String alg=legacy.getString("pin_alg","legacy-sha256");
        String actual="pbkdf2-sha256-120k".equals(alg)?pbkdf2(p,unhex(oldSalt)):hex(MessageDigest.getInstance("SHA-256").digest((oldSalt+":"+p).getBytes(StandardCharsets.UTF_8)));
        boolean ok=MessageDigest.isEqual(actual.getBytes(StandardCharsets.US_ASCII),oldHash.getBytes(StandardCharsets.US_ASCII));
        if(ok){byte[] fresh=new byte[16];new SecureRandom().nextBytes(fresh);prefs.edit().putString("pin_salt",hex(fresh)).putString("pin_hash",pbkdf2(p,fresh)).apply();}
        return ok;
    }catch(Exception e){return false;}}
    private static String pbkdf2(String password,byte[] salt){PBEKeySpec spec=new PBEKeySpec(password.toCharArray(),salt,120000,256);
        try{ return hex(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded());}catch(Exception e){throw new IllegalStateException(e);}finally{spec.clearPassword();}}
    private static byte[] unhex(String s){byte[] a=new byte[s.length()/2];for(int i=0;i<a.length;i++)a[i]=(byte)Integer.parseInt(s.substring(i*2,i*2+2),16);return a;}
    private static String hex(byte[] a){StringBuilder s=new StringBuilder();for(byte v:a)s.append(String.format(Locale.US,"%02x",v&255));return s.toString();}
    private void immersive(){getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);}
    private boolean pinned(){ActivityManager am=(ActivityManager)getSystemService(Context.ACTIVITY_SERVICE);return am!=null&&am.getLockTaskModeState()!=ActivityManager.LOCK_TASK_MODE_NONE;}
    @Override public void onWindowFocusChanged(boolean focused){super.onWindowFocusChanged(focused);if(active){if(focused){immersive();record("FOCUS_RETURN","Layar mendapat fokus, screen pin aktif="+pinned());if(!pinned()&&status!=null)status.setText("PERINGATAN: Screen Pinning tidak aktif");}
        else record("FOCUS_LOSS","Jendela kehilangan fokus (penyebab tidak diketahui)");}}
    @Override protected void onPause(){if(active)record("APP_PAUSE","Aplikasi kehilangan status aktif");super.onPause();}
    @Override protected void onResume(){super.onResume();if(active){record("APP_RESUME","Aplikasi aktif kembali, pin="+pinned());immersive();}}
    @Override public void onBackPressed(){if(active)record("BACK_BLOCKED","Tombol Back ditolak");else super.onBackPressed();}
    @Override protected void onDestroy(){handler.removeCallbacks(heartbeat);if(web!=null){web.destroy();web=null;}io.shutdown();super.onDestroy();}
}
