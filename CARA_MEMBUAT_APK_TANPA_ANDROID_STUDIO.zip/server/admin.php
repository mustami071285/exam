<?php
declare(strict_types=1);
require __DIR__.'/bootstrap.php';
ini_set('session.use_strict_mode','1');
ini_set('session.cookie_httponly','1');
ini_set('session.cookie_secure','1');
ini_set('session.cookie_samesite','Strict');
session_start();
if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(24));
function h($s):string {return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function csrf():string {return '<input type="hidden" name="csrf" value="'.h($_SESSION['csrf']).'">';}
$err='';$ok='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!hash_equals($_SESSION['csrf'],(string)($_POST['csrf']??''))) $err='Permintaan tidak valid';
 else {
  $action=$_POST['action']??'';
  if($action==='login'){
   $user=sqlone('SELECT * FROM admins WHERE username=?',[(string)($_POST['username']??'')]);
   if($user && password_verify((string)($_POST['password']??''),$user['password_hash'])){session_regenerate_id(true);$_SESSION['admin']=(int)$user['id'];header('Location: admin.php');exit;}
   $err='Login gagal';
  }elseif($action==='logout'){$_SESSION=[];session_destroy();header('Location: admin.php');exit;}
  elseif(empty($_SESSION['admin'])) $err='Silakan login';
  elseif($action==='student'){
   $nis=trim((string)($_POST['nis']??''));$name=trim((string)($_POST['name']??''));$pwd=(string)($_POST['password']??'');
   if($nis===''||strlen($nis)>40||$name===''||strlen($name)>120||strlen($pwd)<8) $err='NIS, nama, atau kata sandi tidak valid (min. 8 karakter)';
   else {try{$q=db()->prepare('INSERT INTO students(nis,name,password_hash) VALUES(?,?,?)');$q->execute([$nis,$name,password_hash($pwd,PASSWORD_DEFAULT)]);$ok='Siswa ditambahkan';}catch(PDOException $ex){$err='NIS sudah ada atau data tidak valid';}}
  }elseif($action==='exam'){
   $title=trim((string)($_POST['title']??''));$url=trim((string)($_POST['url']??''));$token=(string)($_POST['token']??'');$start=(string)($_POST['start']??'');$end=(string)($_POST['end']??'');
   $start=str_replace('T',' ',$start).':00';$end=str_replace('T',' ',$end).':00';
   if($title===''||strlen($title)>160||!examUrlOk($url)||strlen($url)>2048||strlen($token)<8||!strtotime($start)||!strtotime($end)||strtotime($end)<=strtotime($start)) $err='Judul, HTTPS URL, token (min. 8), atau jadwal tidak valid';
   else {$q=db()->prepare('INSERT INTO exams(title,exam_url,token_hash,starts_at,ends_at) VALUES(?,?,?,?,?)');$q->execute([$title,$url,password_hash($token,PASSWORD_DEFAULT),$start,$end]);$ok='Ujian ditambahkan. Simpan token yang dibuat karena tidak bisa dilihat lagi.';}
  }elseif($action==='toggle'){
    $kind=(string)($_POST['kind']??'');$id=(int)($_POST['id']??0);
    if(in_array($kind,['exams','students'],true)&&$id>0) {db()->prepare("UPDATE $kind SET active=1-active WHERE id=?")->execute([$id]);$ok='Status diperbarui';}
  }
 }
}
$logged=!empty($_SESSION['admin']);
if($logged){
 $exams=db()->query('SELECT e.*,COUNT(DISTINCT s.id) AS participants FROM exams e LEFT JOIN sessions s ON s.exam_id=e.id GROUP BY e.id ORDER BY e.id DESC LIMIT 100')->fetchAll();
 $students=db()->query('SELECT id,nis,name,active FROM students ORDER BY id DESC LIMIT 100')->fetchAll();
 $sessions=db()->query('SELECT se.id,st.nis,st.name,e.title,se.started_at,se.last_seen,se.ended_at,COUNT(ev.id) events_count FROM sessions se JOIN students st ON st.id=se.student_id JOIN exams e ON e.id=se.exam_id LEFT JOIN events ev ON ev.session_id=se.id GROUP BY se.id ORDER BY se.id DESC LIMIT 100')->fetchAll();
 $filter=(int)($_GET['session']??0);
 $events=[];if($filter){$q=db()->prepare('SELECT event_type,detail,client_at,received_at FROM events WHERE session_id=? ORDER BY id DESC LIMIT 300');$q->execute([$filter]);$events=$q->fetchAll();}
}
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Exam Browser</title><style>body{font:15px system-ui,sans-serif;background:#f3f6fa;color:#14263a;margin:0}header{background:#123b65;color:white;padding:20px}main{max-width:1140px;margin:20px auto;padding:0 15px}.card{background:white;border-radius:12px;padding:18px;margin:14px 0;box-shadow:0 2px 14px #1232}input{padding:10px;margin:4px;max-width:95%;border:1px solid #abc;border-radius:6px}button{padding:10px 16px;background:#1764a4;color:white;border:0;border-radius:6px;cursor:pointer}table{border-collapse:collapse;width:100%;font-size:13px}td,th{border-bottom:1px solid #ddd;padding:9px;text-align:left;vertical-align:top}section{overflow-x:auto}.err{color:#a21}.ok{color:#176d2b}a{color:#125c9b}</style></head><body><header><strong>Exam Browser — Dashboard Sekolah</strong></header><main>
<?php if($err):?><p class="err"><?=h($err)?></p><?php endif;?><?php if($ok):?><p class="ok"><?=h($ok)?></p><?php endif;?>
<?php if(!$logged):?><div class="card"><h2>Login administrator</h2><form method="post"><?=csrf()?><input type="hidden" name="action" value="login"><input name="username" placeholder="Username" required><input type="password" name="password" placeholder="Kata sandi" required><button>Masuk</button></form></div>
<?php else:?>
<form method="post"><?=csrf()?><input type="hidden" name="action" value="logout"><button>Keluar</button></form>
<div class="card"><h2>Tambah siswa</h2><form method="post"><?=csrf()?><input type="hidden" name="action" value="student"><input name="nis" placeholder="NIS" maxlength="40" required><input name="name" placeholder="Nama siswa" maxlength="120" required><input name="password" type="password" minlength="8" placeholder="Kata sandi siswa" required><button>Simpan siswa</button></form></div>
<div class="card"><h2>Tambah ujian</h2><p>Waktu mengikuti zona server: <?=h(date_default_timezone_get())?></p><form method="post"><?=csrf()?><input type="hidden" name="action" value="exam"><input name="title" placeholder="Mata pelajaran / judul" required><input name="url" type="url" placeholder="https://cbt.sekolah.sch.id/ujian" size="38" required><input name="token" placeholder="Token ujian (min. 8 karakter)" minlength="8" required><input name="start" type="datetime-local" required><input name="end" type="datetime-local" required><button>Buat ujian</button></form></div>
<div class="card"><h2>Daftar ujian</h2><section><table><tr><th>Judul</th><th>Jadwal</th><th>Peserta sesi</th><th>Status</th></tr><?php foreach($exams as $e):?><tr><td><?=h($e['title'])?></td><td><?=h($e['starts_at'])?> — <?=h($e['ends_at'])?></td><td><?=h($e['participants'])?></td><td><?=!$e['active']?'Nonaktif':'Aktif'?> <form method="post" style="display:inline"><?=csrf()?><input type="hidden" name="action" value="toggle"><input type="hidden" name="kind" value="exams"><input type="hidden" name="id" value="<?=h($e['id'])?>"><button>Ubah</button></form></td></tr><?php endforeach;?></table></section></div>
<div class="card"><h2>Daftar siswa (100 terakhir)</h2><section><table><tr><th>NIS</th><th>Nama</th><th>Status</th></tr><?php foreach($students as $st):?><tr><td><?=h($st['nis'])?></td><td><?=h($st['name'])?></td><td><?=h($st['active']?'Aktif':'Nonaktif')?></td></tr><?php endforeach;?></table></section></div>
<div class="card"><h2>Sesi dan laporan (100 terbaru)</h2><p>Data hanya menunjukkan kejadian yang berhasil dicatat aplikasi, bukan bukti pelanggaran.</p><section><table><tr><th>Siswa</th><th>Ujian</th><th>Mulai</th><th>Aktivitas terakhir</th><th>Jumlah laporan</th></tr><?php foreach($sessions as $s):?><tr><td><?=h($s['nis'].' — '.$s['name'])?></td><td><?=h($s['title'])?></td><td><?=h($s['started_at'])?></td><td><?=h($s['ended_at']?'Selesai '.$s['ended_at']:($s['last_seen']??'-'))?></td><td><a href="?session=<?=h($s['id'])?>"><?=h($s['events_count'])?> kejadian</a></td></tr><?php endforeach;?></table></section></div>
<?php if($filter):?><div class="card"><h2>Detail kejadian sesi #<?=h($filter)?></h2><section><table><tr><th>Server menerima</th><th>Jam HP</th><th>Jenis</th><th>Keterangan</th></tr><?php foreach($events as $ev):?><tr><td><?=h($ev['received_at'])?></td><td><?=h($ev['client_at'])?></td><td><?=h($ev['event_type'])?></td><td><?=h($ev['detail'])?></td></tr><?php endforeach;?></table></section></div><?php endif;?>
<?php endif;?></main></body></html>
