<?php
declare(strict_types=1);
require __DIR__.'/bootstrap.php';
header('Cache-Control: no-store');
if (($_SERVER['REQUEST_METHOD']??'')!=='POST') fail(405,'Gunakan POST');
$action=$_GET['action']??'';
$d=body();
if ($action==='login') {
 $nis=strvalreq($d,'nis',40);$password=strvalreq($d,'password',120);$token=strvalreq($d,'exam_token',100);$nonce=strvalreq($d,'client_nonce',80);
 if ($nis===''||$password===''||$token===''||!preg_match('/^[A-Za-z0-9_-]{12,80}$/',$nonce)) fail(400,'Lengkapi identitas dan token');
 $ipHash=hash('sha256',(string)($_SERVER['REMOTE_ADDR']??'unknown'));
 $failures=sqlone('SELECT COUNT(*) AS n FROM login_attempts WHERE ip_hash=? AND attempted_at>=DATE_SUB(NOW(),INTERVAL 15 MINUTE)',[$ipHash]);
 if ((int)$failures['n']>=12) fail(429,'Terlalu banyak percobaan login. Coba 15 menit lagi');
 $st=sqlone('SELECT * FROM students WHERE nis=? AND active=1',[$nis]);
 if (!$st||!password_verify($password,$st['password_hash'])) {
    db()->prepare('INSERT INTO login_attempts(ip_hash,attempted_at) VALUES(?,NOW())')->execute([$ipHash]);
    fail(401,'NIS atau kata sandi tidak sesuai');
 }
 $ex=db()->query('SELECT * FROM exams WHERE active=1 AND starts_at<=NOW() AND ends_at>=NOW() ORDER BY id DESC LIMIT 100')->fetchAll();
 $match=null;
 foreach($ex as $e){if(password_verify($token,$e['token_hash'])){$match=$e;break;}}
 if (!$match) {
    db()->prepare('INSERT INTO login_attempts(ip_hash,attempted_at) VALUES(?,NOW())')->execute([$ipHash]);
    fail(403,'Token salah atau ujian di luar jadwal');
 }
 if (!examUrlOk($match['exam_url'])) fail(500,'URL ujian tidak aman');
 $raw=rtrim(strtr(base64_encode(random_bytes(36)),'+/','-_'),'=');
 $q=db()->prepare('INSERT INTO sessions(exam_id,student_id,bearer_hash,started_at,last_seen,client_nonce) VALUES(?,?,?,?,?,?)');
 $q->execute([$match['id'],$st['id'],hash('sha256',$raw),now(),now(),$nonce]);
 jsonout(['ok'=>true,'session_token'=>$raw,'exam_url'=>$match['exam_url'],'exam_title'=>$match['title'],'student_name'=>$st['name'],'ends_at'=>$match['ends_at'],'server_time'=>now()],201);
}
$s=tokenRecord();
if ($action==='events') {
 $events=$d['events']??null;if(!is_array($events)||count($events)>50) fail(400,'Maksimal 50 kejadian');
 $q=db()->prepare('INSERT IGNORE INTO events(session_id,event_uuid,event_type,detail,client_at,received_at) VALUES(?,?,?,?,?,?)');
 foreach($events as $e) {
  if(!is_array($e)) fail(400,'Format kejadian salah');
  $uuid=strvalreq($e,'uuid',36);$type=strvalreq($e,'type',50);$detail=strvalreq($e,'detail',500);$at=strvalreq($e,'at',40);
  if(!preg_match('/^[0-9a-f-]{36}$/i',$uuid)||!preg_match('/^[A-Z_]{3,50}$/',$type)) fail(400,'Jenis atau ID kejadian salah');
  $q->execute([$s['id'],$uuid,$type,$detail,$at,now()]);
 }
 db()->prepare('UPDATE sessions SET last_seen=? WHERE id=?')->execute([now(),$s['id']]);
 jsonout(['ok'=>true,'accepted'=>count($events),'server_time'=>now()]);
}
if($action==='heartbeat') {
 db()->prepare('UPDATE sessions SET last_seen=? WHERE id=?')->execute([now(),$s['id']]);
 jsonout(['ok'=>true,'server_time'=>now(),'ends_at'=>$s['ends_at']]);
}
if($action==='finish') {
 db()->prepare('UPDATE sessions SET ended_at=?,last_seen=? WHERE id=?')->execute([now(),now(),$s['id']]);
 jsonout(['ok'=>true]);
}
fail(404,'Endpoint tidak dikenal');
