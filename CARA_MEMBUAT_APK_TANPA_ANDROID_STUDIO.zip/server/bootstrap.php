<?php
declare(strict_types=1);
$configFile=__DIR__.'/config.php';
if (!is_file($configFile)) { http_response_code(503); exit('Server belum dikonfigurasi'); }
$cfg=require $configFile;
date_default_timezone_set($cfg['timezone'] ?? 'Asia/Jakarta');
if (!empty($cfg['https_required']) && PHP_SAPI!=='cli') {
 $https=(!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off');
 if (!$https) { http_response_code(403); exit('HTTPS diperlukan'); }
}
function db():PDO {
 global $cfg; static $db;
 if (!$db) $db=new PDO($cfg['dsn'],$cfg['db_user'],$cfg['db_pass'],[
 PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
 PDO::ATTR_EMULATE_PREPARES=>false]);
 if (!isset($GLOBALS["db_tz_set"])) { $db->exec("SET time_zone = '+07:00'"); $GLOBALS["db_tz_set"] = true; }
 return $db;
}
function sqlone(string $sql,array $params=[]):array|false { $s=db()->prepare($sql);$s->execute($params);return $s->fetch(); }
function fail(int $code,string $message):never { http_response_code($code);header('Content-Type: application/json; charset=utf-8');echo json_encode(['ok'=>false,'message'=>$message]);exit; }
function jsonout(array $data,int $status=200):never { http_response_code($status);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode($data,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);exit; }
function body():array { if ((int)($_SERVER['CONTENT_LENGTH']??0)>65536) fail(413,'Data terlalu besar');$d=json_decode(file_get_contents('php://input'),true);if (!is_array($d)) fail(400,'JSON tidak valid');return $d; }
function strvalreq(array $d,string $key,int $max):string { $v=$d[$key]??''; if (!is_string($v)||strlen($v)>$max) fail(400,'Kolom '.$key.' tidak valid');return trim($v); }
function now():string { return date('Y-m-d H:i:s'); }
function examUrlOk(string $url):bool {
 $p=parse_url($url);return $p!==false && ($p['scheme']??'')==='https' && !empty($p['host']) && !isset($p['user']) && !isset($p['pass']) && !isset($p['fragment']) && !isset($p['port']);
}
function tokenRecord():array {
 $h=$_SERVER['HTTP_AUTHORIZATION']??'';
 if (!preg_match('/^Bearer ([A-Za-z0-9_-]{32,128})$/',$h,$m)) fail(401,'Sesi tidak valid');
 $s=sqlone('SELECT s.*,e.ends_at,e.active AS exam_active,st.active AS student_active FROM sessions s JOIN exams e ON e.id=s.exam_id JOIN students st ON st.id=s.student_id WHERE s.bearer_hash=?',[hash('sha256',$m[1])]);
 if (!$s||$s['ended_at']!==null||!$s['exam_active']||!$s['student_active']||$s['ends_at']<now()) fail(401,'Sesi sudah berakhir');
 return $s;
}
