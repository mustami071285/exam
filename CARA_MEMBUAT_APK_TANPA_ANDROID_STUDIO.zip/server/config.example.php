<?php
// Salin ke config.php, jangan simpan dalam repositori publik.
return [
  'dsn' => 'mysql:host=localhost;dbname=exam_browser;charset=utf8mb4',
  'db_user' => 'exam_user',
  'db_pass' => 'GANTI_PASSWORD_DB',
  'timezone' => 'Asia/Jakarta',
  'https_required' => true,
];
