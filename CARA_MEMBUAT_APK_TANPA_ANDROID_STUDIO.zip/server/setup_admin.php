<?php
// Jalankan dari CLI: php setup_admin.php namaadmin passwordkuat
if(PHP_SAPI!=='cli') {http_response_code(403);exit('CLI only');}
require __DIR__.'/bootstrap.php';
if($argc!==3 || strlen($argv[2])<12){fwrite(STDERR,"Cara: php setup_admin.php admin PasswordMinimal12Karakter\n");exit(1);}
$q=db()->prepare('INSERT INTO admins(username,password_hash) VALUES(?,?) ON DUPLICATE KEY UPDATE password_hash=VALUES(password_hash)');
$q->execute([$argv[1],password_hash($argv[2],PASSWORD_DEFAULT)]);
echo "Akun admin disimpan. Hapus perintah password dari riwayat shell bila perlu.\n";
